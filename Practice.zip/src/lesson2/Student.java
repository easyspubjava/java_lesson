package lesson2;

public class Student {

	int studentId;
	String studentName;
	int grade;
	
	
}
