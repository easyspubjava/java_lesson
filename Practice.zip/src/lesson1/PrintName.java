package lesson1;

public class PrintName {

	public static void main(String[] args) {
		System.out.println("ȫ�浿");
	}
}
