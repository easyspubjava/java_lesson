package lesson9;

public interface Scheduler {

	public void getNextCall();
	public void sendCallToAgent();
	
}
