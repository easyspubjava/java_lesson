package lesson10;

public interface Stack {

	void push(String title);
	String pop();
	int getSize();
}
